/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 *
 * @author user
 */
public class Cars{
    
    private String modelName;
    private String brandName;
    private LocalDate dateOfManufacturing;
    private int numOfSeats;
    private String serialNum;
    private boolean maintenanceCertificate;
    private LocalDateTime timestampAvailableChange;
    private boolean availabilty;
    private String city;

    public LocalDateTime getTimestampAvailableChange() {
        return timestampAvailableChange;
    }

    public void setTimestampAvailableChange() {
        this.timestampAvailableChange = LocalDateTime.now();
    }
    
    public boolean isAvailabilty() {
        return availabilty;
    }

    public void setAvailabilty(boolean availabilty) {
        this.availabilty = availabilty;
        this.setTimestampAvailableChange();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
    
    
    //Getters & Setters

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public LocalDate getDateOfManufacturing() {
        return dateOfManufacturing;
    }

    public void setDateOfManufacturing(LocalDate dateOfManufacturing) {
        this.dateOfManufacturing = dateOfManufacturing;
        this.setMaintenanceCertificate();
    }

    public int getNumOfSeats() {
        return numOfSeats;
    }

    public void setNumOfSeats(int numOfSeats) {
        this.numOfSeats = numOfSeats;
    }

    public String getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }

    public boolean isMaintenanceCertificate() {
        return maintenanceCertificate;
    }

    public void setMaintenanceCertificate() {
        if(this.getDateOfManufacturing().getYear() + 1 > LocalDate.now().getYear()){
            this.maintenanceCertificate = true;
        }else maintenanceCertificate = false;
    }

    public LocalDate getMaintenanceDate() {
        return maintenanceDate;
    }

    public void setMaintenanceDate(LocalDate maintenanceDate) {
        this.maintenanceDate = maintenanceDate;
    }
    private LocalDate maintenanceDate;

    public String getName() {
        return modelName;
    }

    public void setName(String name) {
        this.modelName = name;
    }
    
    @Override
    public String toString(){
        return modelName;
    }
    
}
