/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author user
 */
public class CarCatalog {
    
    private ArrayList<Cars> carCatalog;
    private LocalDateTime lastUpdated;

    public LocalDateTime getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated() {
        this.lastUpdated = LocalDateTime.now();
    }
    
    public CarCatalog(){
        
        this.carCatalog = new ArrayList<Cars>();
    }

    public ArrayList<Cars> getCarCatalog() {
        return carCatalog;
    }

    public void setCarCatalog(ArrayList<Cars> carCatalog) {
        this.carCatalog = carCatalog;
    }
    
    public Cars addNewCar(){
        
        Cars newCar = new Cars();
        carCatalog.add(newCar);
        this.setLastUpdated();
        
        return newCar;
        
    }

    public void deleteCar(Cars selectedCar) {
            
        carCatalog.remove(selectedCar);
        this.setLastUpdated();

    }
    
}
