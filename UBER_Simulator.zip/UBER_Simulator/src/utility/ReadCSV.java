/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;
import model.CarCatalog;
import model.Cars;

/**
 *
 * @author user
 */
public class ReadCSV {
    
    CarCatalog allCars;
    
    public ReadCSV(CarCatalog allCars){
        this.allCars = allCars;
    }
    
    
    
    public void bulkLoad()   
    {  
        String line = "";  
        String splitBy = ",";  
        
        UtilityFunctions util = new UtilityFunctions();
        
        try   
        {  
            //parsing a CSV file into BufferedReader class constructor  
            BufferedReader br = new BufferedReader(new FileReader("bulk_load.csv"));  
            while ((line = br.readLine()) != null)   //returns a Boolean value  
            {  
                String[] car = line.split(splitBy);    // use comma as separator  
                
                String modelName = car[0];
                String brandName = car[1];
                LocalDate manfacturingYear = util.convertToDate("1-Jan-"+car[2]);
                int numOfSeats = util.convertToInt(car[3]);
                String serialNumber = car[4];
                boolean availability = car[5].equals("TRUE");
                String city = car[6];
                
                //Load the car
                Cars newCar = allCars.addNewCar();
                
                //Set the fields
                newCar.setModelName(modelName);
                newCar.setBrandName(brandName);
                newCar.setDateOfManufacturing(manfacturingYear);
                newCar.setNumOfSeats(numOfSeats);
                newCar.setSerialNum(serialNumber);
                newCar.setAvailabilty(availability);
                newCar.setCity(city);
                
            }  
        }   
        catch (IOException e)   
        {  
            e.printStackTrace();  
        }  
    }  

}
